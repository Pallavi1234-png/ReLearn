import React from 'react'
import ReactDOM from 'react-dom/client'
import 'katex/dist/katex.min.css'
import './index.css'
import App from './App.jsx'
ReactDOM.createRoot(document.getElementById('root')).render(<App />)
